class_name ParryWindow
extends RefCounted
## Pure tick-based parry judgment for the first boss's overhead slam.
## No engine time, no scene tree, no wall clock — integer physics ticks only.
## Baseline: 60 physics ticks per second (Godot default).

const PARRY_WINDOW_TICKS := 8    ## window opens 8 ticks (~133ms) before impact
const INPUT_BUFFER_TICKS := 4    ## presses up to 4 ticks before the window still count
const PERFECT_STAGGER_TICKS := 30
const NO_PRESS := -1             ## sentinel: player never pressed parry

enum Result { PERFECT_PARRY, BLOCK, HIT }

## press_tick: tick when parry was pressed (NO_PRESS if never)
## hit_tick:   tick when the boss's attack lands
## shield_held: whether a regular block was active at impact
static func judge(press_tick: int, hit_tick: int, shield_held: bool) -> Result:
	var window_open := hit_tick - PARRY_WINDOW_TICKS - INPUT_BUFFER_TICKS
	if press_tick != NO_PRESS and press_tick >= window_open and press_tick <= hit_tick:
		return Result.PERFECT_PARRY
	if shield_held:
		return Result.BLOCK
	return Result.HIT
