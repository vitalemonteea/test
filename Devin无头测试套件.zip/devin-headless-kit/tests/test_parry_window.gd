extends GutTest
## GUT suite for the parry window. Runs fully headless:
## godot --headless --path . --fixed-fps 60 -s addons/gut/gut_cmdln.gd -gdir=res://tests -ginclude_subdirs -gexit

const PW = preload("res://combat/parry_window.gd")
const HIT := 60  ## impact tick used across cases; window opens at 60-8-4 = 48

func test_press_at_window_open_is_perfect() -> void:
	assert_eq(PW.judge(48, HIT, false), PW.Result.PERFECT_PARRY)

func test_press_at_impact_tick_is_perfect() -> void:
	assert_eq(PW.judge(HIT, HIT, false), PW.Result.PERFECT_PARRY)

func test_press_one_tick_before_buffer_with_shield_is_block() -> void:
	assert_eq(PW.judge(47, HIT, true), PW.Result.BLOCK)

func test_press_one_tick_late_with_shield_is_block() -> void:
	assert_eq(PW.judge(61, HIT, true), PW.Result.BLOCK)

func test_late_press_without_shield_is_hit() -> void:
	assert_eq(PW.judge(61, HIT, false), PW.Result.HIT)

func test_no_press_no_shield_is_hit() -> void:
	assert_eq(PW.judge(PW.NO_PRESS, HIT, false), PW.Result.HIT)

func test_no_press_with_shield_is_block() -> void:
	assert_eq(PW.judge(PW.NO_PRESS, HIT, true), PW.Result.BLOCK)

## Exhaustive boundary sweep: every offset in [-20, +20] around impact.
## If anyone mutates the window constants, this fails immediately.
func test_window_boundary_sweep() -> void:
	for offset in range(-20, 21):
		var press := HIT + offset
		var expected: int
		if offset >= -(PW.PARRY_WINDOW_TICKS + PW.INPUT_BUFFER_TICKS) and offset <= 0:
			expected = PW.Result.PERFECT_PARRY
		else:
			expected = PW.Result.BLOCK  # shield held in this sweep
		assert_eq(PW.judge(press, HIT, true), expected,
			"offset %d should be %s" % [offset, PW.Result.keys()[expected]])

## Determinism guard: under --fixed-fps 60, awaiting 60 physics frames
## must advance exactly 60 ticks. If the engine ever drops ticks
## (catch-up cap triggered), this fails instead of silently passing.
func test_physics_ticks_advance_deterministically() -> void:
	var start := Engine.get_physics_frames()
	for i in range(60):
		await get_tree().physics_frame
	assert_eq(Engine.get_physics_frames() - start, 60,
		"expected exactly 60 physics ticks; engine dropped or extra-stepped ticks")
